#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/synch.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "filesys/off_t.h"


static void syscall_handler (struct intr_frame *);


void
syscall_init (void) 
{
  lock_init(&file_lock);
  //lock_init(&rc_lock);
  //lock_init(&rw_lock);
  //read_count=0;
  //sema_init(&read_sema, 3);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  //printf("\n%d syscall number\n", *(uint32_t*)(f->esp));
  //hex_dump(f->esp, f->esp, 100, 1);

  switch (*(uint32_t*)(f->esp)){
    case SYS_HALT : 
      halt();
      break;
    case SYS_EXIT : 
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      exit(*(uint32_t*)(f->esp + 4));
      break;
    case SYS_EXEC : 
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      f->eax = exec((const char*)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_WAIT : 
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      f->eax = wait((int)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_CREATE:
      if(!addr_valid(f->esp + 4) || !addr_valid(f->esp + 8)) {
        exit(-1);
      }
      f->eax = create((const char*)*(uint32_t*)(f->esp + 4), (unsigned)*(uint32_t*)(f->esp+8));
      break;
    case SYS_REMOVE:
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      f->eax = remove((const char*)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_OPEN:
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      //hex_dump(f->esp, f->esp, 100, 1);
      f->eax = open((const char*)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_FILESIZE:
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      f->eax = filesize((int)*(uint32_t*)(f->esp+4));
      break;
    case SYS_READ : 
      if(!addr_valid(f->esp + 4) || !addr_valid(f->esp + 8) || !addr_valid(f->esp + 12)) {
        exit(-1);
      }
      f->eax = read((int)*(uint32_t*)(f->esp + 4), (void*)*(uint32_t*)(f->esp + 8), (unsigned)*(uint32_t*)(f->esp + 12));
      break;
    case SYS_WRITE : 
      if(!addr_valid(f->esp + 4) || !addr_valid(f->esp + 8) || !addr_valid(f->esp + 12)) {
        exit(-1);
      }
      f->eax = write((int)*(uint32_t*)(f->esp + 4), (void*)*(uint32_t*)(f->esp + 8), (unsigned)*(uint32_t*)(f->esp + 12));
      break;
    case SYS_SEEK:
      if(!addr_valid(f->esp + 4) || !addr_valid(f->esp + 8)) {
        exit(-1);
      }
      seek((int)*(uint32_t*)(f->esp + 4), (unsigned)*(uint32_t*)(f->esp+8));
      break;
    case SYS_TELL:
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      f->eax = tell((int)*(uint32_t*)(f->esp+4));
      break;
    case SYS_CLOSE:
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      close((int)*(uint32_t*)(f->esp+4));
      break;
    case SYS_FIBO:
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      f->eax = fibonacci((int)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_MAX_FOUR_INT:
      if(!addr_valid(f->esp + 4) || !addr_valid(f->esp + 8) || !addr_valid(f->esp + 12) || !addr_valid(f->esp + 16)) {
        exit(-1);
      }
      f->eax = max_of_four_int((int)*(uint32_t*)(f->esp + 4), (int)*(uint32_t*)(f->esp + 8), (int)*(uint32_t*)(f->esp + 12), (int)*(uint32_t*)(f->esp + 16));
      break;
  }
}

void halt(){
  shutdown_power_off();
}

void exit(int status){
  struct thread* th = thread_current();
  printf("%s: exit(%d)\n", th -> name, status);

  th->exit_status = status;
  for(int i=fd_start;i<fd_end;i++){
    if(th->fd[i]!=NULL){
      close(i);
    }
  }
  thread_exit();
}

pid_t exec(const char *cmd_line){
  return process_execute(cmd_line);
}

int wait(pid_t pid){
  return process_wait(pid);
}

int read(int fd, void *buffer, unsigned size){
  int i=0;
  int return_value = -1;
  if (buffer >= PHYS_BASE || fd < 0 || fd >= fd_end) {
     exit(-1);
  }
  lock_acquire(&file_lock);
  
  if(fd ==0){
    //file_deny_write(thread_current()->fd[0]);
    while(i<=size){
      if(input_getc() == '\0') {
        if(i != size) {
          lock_release(&file_lock);
          //file_allow_write(thread_current()->fd[0]);
          return i;
        }
        else {
          lock_release(&file_lock);
          //file_allow_write(thread_current()->fd[0]);
          return size;
        }
      }
      else i++;
    }
  }
  else if (fd >=3 && fd <=127){
    struct file* readf = thread_current()->fd[fd];
    if(!readf){
      lock_release(&file_lock);
      exit(-1);
    }
    return_value = file_read(readf, buffer, size);
    lock_release(&file_lock);
    return return_value;
  }
  else {
    lock_release(&file_lock);
    return return_value;
  }
  //lock_acquire(&rc_lock);
  //read_count--;
  //if(read_count==0){
  // lock_release(&rw_lock);
  //}
  //lock_release(&rc_lock);
}

int write(int fd, const void *buffer, unsigned size){
  int return_value = -1;
  if (buffer >= PHYS_BASE || fd < 0 || fd >= fd_end) {
     exit(-1);
  }
  //lock_try_acquire(&file_lock);
  lock_acquire(&file_lock);
  //lock_acquire(&rw_lock);
  if(fd ==1){
      putbuf(buffer, size);
      return_value = size;
  }
  else if (fd >=fd_start && fd <=fd_end-1){
    struct file* writef = thread_current()->fd[fd];
    if(!writef){
      //lock_release(&rw_lock);
      lock_release(&file_lock);
      exit(-1);
    }
    if(writef->deny_write){
      file_deny_write(writef);
    }
    return_value = file_write(writef, buffer, size);
  }
  else{
    lock_release(&file_lock);
    exit(-1);
  }
  //lock_release(&rw_lock);
  lock_release(&file_lock);
  return return_value;
}

int fibonacci(int n){
  int prev2 = 1;
  int prev1 = 1;
  int result = 0;
  if(n>=2){
    for(int i=0;i<n-2;i++){
      result = prev1 + prev2;
      prev2 = prev1;
      prev1 = result;
    }
    return result;
  }
  else return 1;
}

int max_of_four_int(int a, int b, int c, int d){
  int max = 0;
  if(a > b){
    max = a;
  }
  else max = b;

  if(max < c){
    max = c;
  }

  if(max < d){
    max = d;
  }
  return max;
}

bool addr_valid(void *addr){
  if(is_user_vaddr(addr)){
    return true;
  }
  return false;
}

int open(const char *file){
  int return_value = -1;
  if(!file){
    return -1;
  }
  lock_acquire(&file_lock);
  struct file* fp = filesys_open(file);

  if(!fp){
    lock_release(&file_lock);
    return -1;
  }

  if(strcmp(thread_current()->name, file) ==0){
    file_deny_write(fp);
  }
  int i=fd_start;
  while(i<=fd_end-1){
    if(thread_current()->fd[i]==NULL){
      thread_current()->fd[i] = fp;
      return_value = i;
      break;
    }
    else i++;
  }
  lock_release(&file_lock);
  return return_value;
}

bool create(const char* file, unsigned initial_size){
  if(file == NULL||(uint32_t)file+initial_size-1>=PHYS_BASE){
    exit(-1);
  }
  return filesys_create(file, initial_size);
}

int filesize(int fd){
  int return_value=-1;
  if(!thread_current()->fd[fd]){
    exit(-1);
  }
  //lock_acquire(&file_lock);
  return_value = file_length(thread_current() -> fd[fd]);
  //lock_release(&file_lock);
  return return_value;
}

void seek(int fd, unsigned position){
  if (thread_current()->fd[fd] == NULL || position >= PHYS_BASE) {
    exit(-1);
  }
  //lock_acquire(&file_lock);
  file_seek(thread_current()->fd[fd], position);
  //lock_release(&file_lock);
}

unsigned tell(int fd){
  unsigned return_value = -1;
  if (thread_current()->fd[fd] == NULL) {
    exit(-1);
  }
  //lock_acquire(&file_lock);
  return_value =  file_tell(thread_current()->fd[fd]);
  //lock_release(&file_lock);
  return return_value;
}

void close(int fd){
  if(thread_current()->fd[fd]){
    file_close(thread_current()->fd[fd]);
    thread_current()->fd[fd] = NULL;
  }
  else {
    exit(-1);
  }
}

bool remove(const char* file){
  bool return_value=true;
  if (file == NULL) {
    exit(-1);
  }
  //lock_acquire(&file_lock);
  return_value = filesys_remove(file);
  //lock_release(&file_lock);
  return return_value;
}
