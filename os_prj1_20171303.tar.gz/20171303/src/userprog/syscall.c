#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"

typedef int pid_t;

static void syscall_handler (struct intr_frame *);
void halt (void);
void exit (int status);
int exec (const char *file);
int wait(int pid);
int read (int fd, void *buffer, unsigned length);
int write (int fd, const void *buffer, unsigned length);
bool addr_valid(void *addr);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  //printf("\n%d syscall number\n", *(uint32_t*)(f->esp));
  //hex_dump(f->esp, f->esp, 100, 1);

  switch (*(uint32_t*)(f->esp)){
    case SYS_HALT : 
      halt();
      break;
    case SYS_EXIT : 
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      exit(*(uint32_t*)(f->esp + 4));
      break;
    case SYS_EXEC : 
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      f->eax = exec((const char*)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_WAIT : 
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      f->eax = wait((int)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_CREATE:
      break;
    case SYS_REMOVE:
      break;
    case SYS_OPEN:
      break;
    case SYS_FILESIZE:
      break;
    case SYS_READ : 
      if(!addr_valid(f->esp + 20) || !addr_valid(f->esp + 24) || !addr_valid(f->esp + 28)) {
        exit(-1);
      }
      f->eax = read((int)*(uint32_t*)(f->esp + 4), (void*)*(uint32_t*)(f->esp + 8), (unsigned)*(uint32_t*)(f->esp + 12));
      //read((uint32_t)(esp_point+4), (void)(esp_point+8), (unsigned)(esp_point+12));
      break;
    case SYS_WRITE : 
      if(!addr_valid(f->esp + 20) || !addr_valid(f->esp + 24) || !addr_valid(f->esp + 28)) {
        exit(-1);
      }
      f->eax = write((int)*(uint32_t*)(f->esp + 20), (void*)*(uint32_t*)(f->esp + 24), (unsigned)*(uint32_t*)(f->esp + 28));
      break;
    case SYS_SEEK:
      break;
    case SYS_TELL:
      break;
    case SYS_CLOSE:
      break;
    case SYS_FIBO:
      if(!addr_valid(f->esp + 4)) {
        exit(-1);
      }
      f->eax = fibonacci((int)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_MAX_FOUR_INT:
    if(!addr_valid(f->esp + 4) || !addr_valid(f->esp + 8) || !addr_valid(f->esp + 12) || !addr_valid(f->esp + 16)) {
        exit(-1);
      }
      f->eax = max_of_four_int((int)*(uint32_t*)(f->esp + 4), (int)*(uint32_t*)(f->esp + 8), (int)*(uint32_t*)(f->esp + 12), (int)*(uint32_t*)(f->esp + 16));
      break;
    break;
  }
}

void halt(){
  shutdown_power_off();
}

void exit(int status){
  struct thread* th = thread_current();
  printf("%s: exit(%d)\n", th -> name, status);

  th->exit_status = status;
  thread_exit();
}

pid_t exec(const char *cmd_line){
  return process_execute(cmd_line);
}

int wait(pid_t pid){

  return process_wait(pid);
}

int read(int fd, void *buffer, unsigned size){
  int i=0;
  if(fd ==0){
    while(i<=size){
      if(input_getc() == '\0') return i;
      else i++;
    }
  }
  return -1;
}

int write(int fd, const void *buffer, unsigned size){
  if(fd ==1){
    putbuf(buffer, size);
    return size;
  }
  return -1;
}

int fibonacci(int n){
  int prev2 = 1;
  int prev1 = 1;
  int result = 0;
  if(n>=2){
    for(int i=0;i<n-2;i++){
      result = prev1 + prev2;
      prev2 = prev1;
      prev1 = result;
    }
    return result;
  }
  else return 1;
}

int max_of_four_int(int a, int b, int c, int d){
  int max = 0;
  if(a > b){
    max = a;
  }
  else max = b;

  if(max < c){
    max = c;
  }

  if(max < d){
    max = d;
  }
  return max;
}

bool addr_valid(void *addr){
  if(is_user_vaddr(addr)){
    return true;
  }
  return false;
}