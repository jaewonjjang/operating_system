/* 
 * echoserveri.c - An iterative echo server 
 */ 
/* $begin echoserverimain */
#include "csapp.h"
#define NTHREADS 10
#define SBUFSIZE 15
#define MAX_STOCK_NUM 15

typedef struct _node{
    int ID;
    int left_stock;
    int price;
    int readcnt;
    sem_t mutex;
}stocknode;
stocknode stock_table[MAX_STOCK_NUM];

typedef struct {
    int *buf;
    int n;
    int front;
    int rear;
    sem_t mutex;
    sem_t slots;
    sem_t items;
}sbuf_t;

void sbuf_init(sbuf_t *sp, int n);
void sbuf_deinit(sbuf_t *sp);
void sbuf_insert(sbuf_t *sp, int item);
int sbuf_remove(sbuf_t *sp);
int sbuf_empty(sbuf_t *sp);


sbuf_t sbuf;
int stock_num = 0; // 주식 종목의 총 갯수
static int byte_cnt;
static sem_t mutex;

void command_client(int connfd);
void *thread(void *vargp);
static void init_command_cnt(void);
int do_command(char* buf2, int n);
void add_tree(int a, int b, int c);
void file_write();
void sigint_handler(int sig);

int main(int argc, char **argv) 
{
    int i, listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
    char client_hostname[MAXLINE], client_port[MAXLINE];
    pthread_t tid;

    if (argc != 2) {
	fprintf(stderr, "usage: %s <port>\n", argv[0]);
	exit(0);
    }
    
    FILE* fp = fopen("stock.txt", "r");
    if (!fp) {
        printf("file open error\n");
        exit(0);
    }
    else {
        int a, b, c, res;
        for(int i=0;i<MAX_STOCK_NUM;i++) {
            stock_table[i].ID = 0;
            stock_table[i].left_stock = 0;
            stock_table[i].price = 0;
            stock_table[i].readcnt = 0;
            Sem_init(&stock_table[i].mutex, 0, 1);
        }
        while (1) {
            res = fscanf(fp, "%d%d%d", &a, &b, &c);
            if(res==EOF) break;
            stock_num++;
            add_tree(a, b, c);
        }
    }
    fclose(fp);
    
    listenfd = Open_listenfd(argv[1]);
    sbuf_init(&sbuf, SBUFSIZE);
    
    for(i=0;i<NTHREADS;i++) {
        Pthread_create(&tid, NULL, thread, NULL);
    }
    while (1) {
	      clientlen = sizeof(struct sockaddr_storage); 
	      connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
        Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
        printf("Connected to (%s, %s)\n", client_hostname, client_port);
        sbuf_insert(&sbuf, connfd);
        if(signal(SIGINT, sigint_handler) ==SIG_ERR) {
            unix_error("signal error\n");
        }
    }
}


void *thread(void *vargp) {
    Pthread_detach(pthread_self());
    while(1) {
        int connfd = sbuf_remove(&sbuf);
        command_client(connfd);
        Close(connfd);
    }
}

static void init_command_cnt(void) {
    Sem_init(&mutex, 0, 1);
    byte_cnt=0;
}

void command_client(int connfd) {
    int n;
    char buf[MAXLINE];
    char buf2[MAXLINE];
    char buf3[MAXLINE];
    rio_t rio;
    static pthread_once_t once = PTHREAD_ONCE_INIT;
    
    Pthread_once(&once, init_command_cnt);
    Rio_readinitb(&rio, connfd);
    
    while((n = Rio_readlineb(&rio, buf, MAXLINE)) !=0) {
        P(&mutex);
        if(!strcmp(buf, "exit\n")) {
            strcpy(buf3, "server close");
            Rio_writen(connfd, buf3, MAXLINE);
            return;
        }
        byte_cnt += n;
        printf("thread %d received %d (%d total) bytes from fd %d\n", (int)pthread_self(), n, byte_cnt, connfd);
        strcpy(buf2, buf);
        switch (do_command(buf2, n)) {
                    case 1: strcpy(buf3, "Not enough left stock\n");
                            Rio_writen(connfd, buf3, MAXLINE);
                            buf3[0] = '\0';
                            break;
                    case 2: strcpy(buf3, "[buy] success\n");
                            Rio_writen(connfd, buf3, MAXLINE);
                            buf3[0] = '\0';
                            break;
                    case 3: strcpy(buf3, "[sell] success\n");
                            Rio_writen(connfd, buf3, MAXLINE);
                            buf3[0] = '\0';
                            break;
                    case 4: strcpy(buf3, "[show] success\n");
                            Rio_writen(connfd, buf2, MAXLINE);
                            buf3[0] = '\0';
                            break;
                    default : strcpy(buf3, "something errer\n");
                            Rio_writen(connfd, buf3, MAXLINE);
                            buf3[0] = '\0';
                            break;
        }
        V(&mutex);
    }
}

void sbuf_init(sbuf_t *sp, int n) {
    sp->buf = Calloc(n, sizeof(int));
    sp->n = n; 
    sp->front = sp->rear = 0; 
    Sem_init(&sp->mutex, 0, 1); 
    Sem_init(&sp->slots, 0, n); 
    Sem_init(&sp->items, 0, 0); 
}

void sbuf_deinit(sbuf_t *sp) {
  Free(sp->buf);
}

int sbuf_empty(sbuf_t *sp) {
    if(sp->front == sp->rear) {
        return 1;
    }
    else return 0;
}

void sbuf_insert(sbuf_t *sp, int item) {
    P(&sp->slots); 
    P(&sp->mutex); 
    sp->buf[(++sp->rear)%(sp->n)] = item; 
    V(&sp->mutex); 
    V(&sp->items); 
}

int sbuf_remove(sbuf_t *sp) {
    int item;
    P(&sp->items); 
    P(&sp->mutex); 
    item = sp->buf[(++sp->front)%(sp->n)]; 
    V(&sp->mutex); 
    V(&sp->slots); 
    return item;
}

void add_tree(int a, int b, int c) {
    stock_table[a].ID = a;
    stock_table[a].left_stock = b;
    stock_table[a].price = c;
}

int do_command(char* buf2, int n) {
    int i, buy_ID, buy_quan, sell_ID, sell_quan;
    int com_idx=0;
    char parse_command[3][MAXLINE];
    char buf4[20];
    
    //printf("%s", buf2);
    
    char *delim = strtok(buf2, " ");
    
    while(delim != NULL) {
        strcpy(parse_command[com_idx++], delim);
        //printf("%s\n", parse_command[com_idx-1]);
        delim = strtok(NULL, " ");
    }
    
    //printf("%s", parse_command[0]);
    
    if (!strcmp(parse_command[0], "buy")) {
        buy_ID = atoi(parse_command[1]);
        buy_quan = atoi(parse_command[2]);
        P(&stock_table[buy_ID].mutex);
        if(stock_table[buy_ID].left_stock < buy_quan ) {
            V(&stock_table[buy_ID].mutex);
            return 1;
        }
        else {
            stock_table[buy_ID].left_stock -= buy_quan;
            V(&stock_table[buy_ID].mutex);
            return 2;
        }
    }
    else if (!strcmp(parse_command[0], "sell")) {
        sell_ID = atoi(parse_command[1]);
        sell_quan = atoi(parse_command[2]);
        P(&stock_table[sell_ID].mutex);
        stock_table[sell_ID].left_stock += sell_quan;
        V(&stock_table[sell_ID].mutex);
        return 3;
        
    }
    else if (!strcmp(parse_command[0], "show\n")) {
        buf2[0] = '\0';
        for(i=1;i<=stock_num;i++) {
        sprintf(buf4, "%d %d %d\n", stock_table[i].ID, stock_table[i].left_stock, stock_table[i].price);
        strcat(buf2, buf4);
        buf4[0] = '\0';
        }
        return 4;
    }
    return 0;
}

void file_write() {
    FILE* fp = fopen("stock.txt", "w");
    if (!fp) {
        printf("file open error\n");
        exit(0);
    }
    else {
        for(int i=1;i<stock_num;i++) {
        fprintf(fp, "%d %d %d\n", stock_table[i].ID, stock_table[i].left_stock, stock_table[i].price);
        }
        fprintf(fp, "%d %d %d", stock_table[stock_num].ID, stock_table[stock_num].left_stock, stock_table[stock_num].price);
    }
    fclose(fp);
}

void sigint_handler(int sig) {
    file_write();
    exit(0);
}

