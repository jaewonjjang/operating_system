/*
 * echoserveri.c - An iterative echo server
 */
 /* $begin echoserverimain */
#include "csapp.h"

#define MAX_STOCK_NUM 20

typedef struct _node{
    int ID;
    int left_stock;
    int price;
}stocknode;

stocknode stock_table[MAX_STOCK_NUM];

typedef struct {
    int maxfd;
    fd_set read_set;
    fd_set ready_set;
    int nready;
    int maxi;
    int clientfd[FD_SETSIZE];
    rio_t clientrio[FD_SETSIZE];
} pool;


int stock_num = 0; // 주식 종목의 총 갯수
int byte_cnt = 0;

void add_tree(int a, int b, int c);
void init_pool(int listenfd, pool *p);
void add_client(int connfd, pool *p);
void command_client(pool *p);
int do_command(char* buf, int n);
void file_write();
void sigint_handler(int sig);

int main(int argc, char** argv)
{
    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
    char client_hostname[MAXLINE], client_port[MAXLINE];
    static pool pool;
    
 
    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }

    FILE* fp = fopen("stock.txt", "r");
    if (!fp) {
        printf("file open error\n");
        exit(0);
    }
    else {
        int a, b, c, res;
        for(int i=0;i<MAX_STOCK_NUM;i++) {
            stock_table[i].ID = 0;
            stock_table[i].left_stock = 0;
            stock_table[i].price = 0;
        }
        while (1) {
            res = fscanf(fp, "%d%d%d", &a, &b, &c);
            if(res==EOF) break;
            stock_num++;
            add_tree(a, b, c);
        }
    }
    fclose(fp);
    //printf("%d %d %d", stock_table[3].price, stock_table[2].left_stock, stock_table[1].ID );
    
    listenfd = Open_listenfd(argv[1]);
    init_pool(listenfd, &pool);
    
    
    while(1) {
        pool.ready_set = pool.read_set;
        pool.nready = Select(pool.maxfd+1, &pool.ready_set, NULL, NULL, NULL);
        
        if(FD_ISSET(listenfd, &pool.ready_set)) {
            clientlen = sizeof(struct sockaddr_storage);
            connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
            Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE, 
                    client_port, MAXLINE, 0);
            printf("Connected to (%s, %s)\n", client_hostname, client_port);
            add_client(connfd, &pool);
            }
            
        command_client(&pool);
        if(signal(SIGINT, sigint_handler) ==SIG_ERR) {
            unix_error("signal error\n");
        }
    }
}
/* $end echoserverimain */

void add_tree(int a, int b, int c) {
    stock_table[a].ID = a;
    stock_table[a].left_stock = b;
    stock_table[a].price = c;
}

void init_pool(int listenfd, pool*p) {
    int i;
    p->maxi = -1;
    for(i=0;i<FD_SETSIZE;i++) {
        p->clientfd[i] = -1;
    }
    
    p->maxfd = listenfd;
    FD_ZERO(&p->read_set);
    FD_SET(listenfd, &p->read_set);
}

void add_client(int connfd, pool *p) {
    int i;
    p->nready--;
    for(i=0; i<FD_SETSIZE;i++) { 
    
        if(p->clientfd[i] < 0) {
            p->clientfd[i] = connfd;
            Rio_readinitb(&p->clientrio[i], connfd);
        
            FD_SET(connfd, &p->read_set);
        
            if(connfd > p->maxfd) p->maxfd = connfd;
            if(i > p->maxi) p->maxi = i;
        
            break;
        }
    }
    
    if(i==FD_SETSIZE) {
        app_error("add clinet error : Too many clients\n");
    }
}

void command_client(pool *p) { 
    int i, connfd, n;
    char buf[MAXLINE];
    char buf2[MAXLINE];
    char buf3[MAXLINE];
    rio_t rio;
    
    for(i=0; (i <= p->maxi) && (p->nready > 0);i++) {
        connfd = p->clientfd[i];
        rio = p->clientrio[i];
        
        if((connfd > 0) && (FD_ISSET(connfd, &p->ready_set))) { 
            p->nready--;
            if((n = Rio_readlineb(&rio, buf, MAXLINE)) !=0) {
                if(!strcmp(buf, "exit\n")) {
                      strcpy(buf3, "server close");
                      Rio_writen(connfd, buf3, MAXLINE);
                      return;
                }
                byte_cnt += n;
                strcpy(buf2, buf);
                printf("Server received %d (%d total) bytes on fd %d\n", n, byte_cnt, connfd);
                //Rio_writen(connfd, buf, MAXLINE);
                
                switch (do_command(buf2, n)) {
                    case 1: strcpy(buf3, "Not enough left stock\n");
                            Rio_writen(connfd, buf3, MAXLINE);
                            buf3[0] = '\0';
                            break;
                    case 2: strcpy(buf3, "[buy] success\n");
                            Rio_writen(connfd, buf3, MAXLINE);
                            buf3[0] = '\0';
                            break;
                    case 3: strcpy(buf3, "[sell] success\n");
                            Rio_writen(connfd, buf3, MAXLINE);
                            buf3[0] = '\0';
                            break;
                    case 4: //strcpy(buf3, "[show] success\n");
                            Rio_writen(connfd, buf2, MAXLINE);
                            buf3[0] = '\0';
                            break;
                    default : strcpy(buf3, "something errer\n");
                            Rio_writen(connfd, buf3, MAXLINE);
                            buf3[0] = '\0';
                            break;
                    }
            }
            else {
                Close(connfd);
                FD_CLR(connfd, &p->read_set);
                p->clientfd[i] = -1;
            }
        }
    }
}

int do_command(char* buf2, int n) {
    int i, buy_ID, buy_quan, sell_ID, sell_quan;
    int com_idx=0;
    char parse_command[3][MAXLINE];
    char buf4[20];
    
    //printf("%s", buf2);
    
    char *delim = strtok(buf2, " ");
    
    while(delim != NULL) {
        strcpy(parse_command[com_idx++], delim);
        //printf("%s\n", parse_command[com_idx-1]);
        delim = strtok(NULL, " ");
    }
    
    //printf("%s", parse_command[0]);
    
    if (!strcmp(parse_command[0], "buy")) {
        buy_ID = atoi(parse_command[1]);
        buy_quan = atoi(parse_command[2]);
        if(stock_table[buy_ID].left_stock < buy_quan ) {
            return 1;
        }
        else {
            stock_table[buy_ID].left_stock -= buy_quan;
            return 2;
        }
    }
    
    else if (!strcmp(parse_command[0], "sell")) {
        sell_ID = atoi(parse_command[1]);
        sell_quan = atoi(parse_command[2]);
        stock_table[sell_ID].left_stock += sell_quan;
        return 3;
    }
    
    else if (!strcmp(parse_command[0], "show\n")) {
        buf2[0] = '\0';
        for(i=1;i<=stock_num;i++) {
        sprintf(buf4, "%d %d %d\n", stock_table[i].ID, stock_table[i].left_stock, stock_table[i].price);
        strcat(buf2, buf4);
        buf4[0] = '\0';
        }
        return 4;
    }
    return 0;
}

void file_write() {
    FILE* fp = fopen("stock.txt", "w");
    if (!fp) {
        printf("file open error\n");
        exit(0);
    }
    else {
        for(int i=1;i<stock_num;i++) {
        fprintf(fp, "%d %d %d\n", stock_table[i].ID, stock_table[i].left_stock, stock_table[i].price);
        }
        fprintf(fp, "%d %d %d", stock_table[stock_num].ID, stock_table[stock_num].left_stock, stock_table[stock_num].price);
    }
    fclose(fp);
}

void sigint_handler(int sig) {
    file_write();
    exit(0);
}
        